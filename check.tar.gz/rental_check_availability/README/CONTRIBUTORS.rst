
Contributors
------------

elego Software Solutions GmbH, Odoo Community Association (OCA)
Ben Brich <b.brich@humanilog.org> (www.humanilog.org), Yu Weng <yweng@elegosoft.com> (www.elegosoft.com)

